# Skeleton

This is the "Skeleton" theme for Massive Wiki Builder.

It is very "bare bones". (ha!)

It does have `_navbar.html` and `_footer.html` partials, and demonstrates how to include them.

It is licensed under the MIT License.
