# Alto

This is the "Alto" theme for Massive Wiki Builder.

It was built with Bulma, with all modules included (at least for now).

It is licensed under the MIT License.
