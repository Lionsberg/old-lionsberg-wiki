# Super Skeleton

This is the "Super Skeleton" theme for Massive Wiki Builder.

It is very "bare bones". (ha!)

It is even more bare bones than the "Skeleton" theme, hence the name, "Super Skeleton".

It is sort of the simplest theme that could possibly work and still use all the features presented to themes by Massive Wiki Builder.

It is licensed under the MIT License.
